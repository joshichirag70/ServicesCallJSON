//
//  SplashModel.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.//

import UIKit
import ObjectMapper

//Error Model
class Errors: Mappable {
    
    var Field       : String?
    var Message     : String?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        
        Field       <- map["Field"]
        Message     <- map["Message"]
    }
}
