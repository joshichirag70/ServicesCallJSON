//
//  Common.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.//

import UIKit
import AVFoundation

class Comman{
    
    func UIColorFromRGB(rgbValue: UInt, alpha: CGFloat) -> UIColor {
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(alpha)
        )
    }
    
    //MARK: Custom NivigationController
    func E_setBackButton_Title_RightButton(viewcontroller:UIViewController, title:String, imageName:String){
        let btnmenu = UIButton(type: .custom)
        btnmenu.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(30), height: CGFloat(40))
        btnmenu.setImage(UIImage(named: imageName)!, for: .normal)
        btnmenu.addTarget(viewcontroller, action: #selector(self.E_BTNavRight), for: .touchUpInside)
        let back = UIBarButtonItem(customView: btnmenu)
        //btnmenu = nil
        let negativeSpacer = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        negativeSpacer.width = -5
        viewcontroller.navigationItem.rightBarButtonItems = [negativeSpacer, back]
        //negativeSpacer = nil
        //back = nil
        E_setBackButtonWithTitle(viewcontroller: viewcontroller, title: title)
    }
    
    func E_setBackButton_Title_RightButton1(viewcontroller:UIViewController, title:String, imageName:String){
        
        let btnmenu = UIButton(type: .custom)
        btnmenu.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(70), height: CGFloat(20))
        // (0,0,60,20) X,Y,Width,Hight
        btnmenu.titleEdgeInsets = UIEdgeInsetsMake(7, 0, 5, 10)
        // Top,Left,Bottom,Right
        btnmenu.setTitle(imageName, for: .normal)
        // btnmenu.titleLabel!.font = Font_RightButton
        //action: #selector(self.imageTapped(gestureRecognizer:))
        btnmenu.addTarget(viewcontroller, action: #selector(Comman().E_BTNavRight), for: .touchUpInside)
        let back = UIBarButtonItem(customView: btnmenu)
        //btnmenu = nil
        let negativeSpacer = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        negativeSpacer.width = -15
        viewcontroller.navigationItem.rightBarButtonItems = [negativeSpacer, back]
        //back = nil
        E_setBackButtonWithTitle(viewcontroller: viewcontroller, title: title)
        
    }
    
    func E_setBackButtonWithTitle(viewcontroller:UIViewController, title:String){
        let btnmenu = UIButton(type: .custom)
        btnmenu.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(30), height: CGFloat(40))
        btnmenu.setImage(UIImage(named: "ic_right_arrowLeft")!, for: .normal)
        btnmenu.setImage(UIImage(named: "ic_right_arrowLeft")!, for: .highlighted)
        btnmenu.addTarget(viewcontroller, action: #selector(Comman().E_BTBack), for: .touchUpInside)
        let back = UIBarButtonItem(customView: btnmenu)
        //btnmenu = nil
        let negativeSpacer = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        negativeSpacer.width = -5
        viewcontroller.navigationItem.leftBarButtonItems = [negativeSpacer, back]
        //negativeSpacer = nil
        //back = nil
        
        if (title.characters.count > 0) {
            let lblTitle = UILabel()
            lblTitle.text = title.uppercased()
            //[lblTitle E_boldSubstring:title];
            //lblTitle.font = Header_Title_Font
            lblTitle.backgroundColor = UIColor.clear
            lblTitle.textColor = UIColor.white
            lblTitle.sizeToFit()
            //viewcontroller.navigationItem.titleView! = lblTitle
            viewcontroller.navigationItem.titleView = lblTitle as UIView
            //lblTitle = nil
        }
    }
    @objc func E_BTBack(){ }            //Navigation Left Button
    @objc func E_BTNavRight(){ }        //Navigation Right Button
    
    //MARK: Animated Button
    func animateButton(button:UIButton) {
        var bubbleSound: SystemSoundID!
        bubbleSound = createBubbleSound()
        AudioServicesPlaySystemSound(bubbleSound)
        button.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 2.0,
                       delay: 0,
                       usingSpringWithDamping: 0.2,
                       initialSpringVelocity: 6.0,
                       options: .allowUserInteraction,
                       animations: { [weak self] in
                        button.transform = .identity
            },
                       completion: nil)
    }
    private func createBubbleSound() -> SystemSoundID {
        var soundID: SystemSoundID = 0
        let soundURL = CFBundleCopyResourceURL(CFBundleGetMainBundle(), "bubble" as CFString!, "mp3" as CFString!, nil)
        AudioServicesCreateSystemSoundID(soundURL!, &soundID)
        return soundID
    }
}





public class Reachability {
    class func isConnectedToNetwork() -> Bool {
        
        /*
         var zeroAddress = sockaddr_in()
         zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
         zeroAddress.sin_family = sa_family_t(AF_INET)
         let defaultRouteReachability = withUnsafePointer(&zeroAddress) {
         SCNetworkReachabilityCreateWithAddress(nil, UnsafePointer($0))
         }
         var flags = SCNetworkReachabilityFlags()
         if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
         return false
         }
         let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
         let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
         return (isReachable && !needsConnection)
         */
        return true;
        
    }
}


class Prefrence {
    
    static let defaults = UserDefaults.standard
    
    static func preferencePutInteger(key : String , value : Int){
        defaults.set(value, forKey: key)
    }
    
    static func preferenceGetInteger(key : String) -> Int {
        return defaults.integer(forKey: key)
    }
    
    static func preferencePutString(key : String , value : String){
        defaults.set(value, forKey: key)
    }
    
    static func preferenceGetString(key : String) -> String? {
        return defaults.string(forKey: key)!
    }
    
    static func preferencePutImage(key : String , value : String){
        defaults.set(value, forKey: key)}
    
    static func preferenceGetImage(key : String) -> String? {
        return defaults.string(forKey: key)!
    }
    
    static func prefrencePutBool(key : String , value : Bool) {
        defaults.set(value, forKey: key)
    }
    
    static func prefrenceGetBool(key : String ) -> Bool {
        return defaults.bool(forKey: key)
    }
    
    static func prefrenceClearAll(){
        let appDomain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: appDomain)
    }
    
    static func tokanExpClear()
    {
        Prefrence.preferencePutString (key: Constant.Preference.PrefToken, value: "")
        Prefrence.preferencePutString (key: Constant.Preference.PrefUserId, value: "")
    }
}


//Mark:Photo PickUp
func generateBoundaryString() -> String {
    return "Boundary-\(NSUUID().uuidString)"
}
func createBodyWithParameters(parameters: [String: String]?, filePathKey: String?, imageDataKey: Data, boundary: String) -> NSData {
    let body = NSMutableData();
    
    var data:Data!
    
    data = "--\(boundary)\r\n".data(using: String.Encoding.isoLatin1)
    //body.append(data!)
    
    if parameters != nil {
        for (key, value) in parameters! {
            body.append(data!)
            data = "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.isoLatin1)
            body.append(data!)
            data = "\(value)\r\n".data(using: String.Encoding.isoLatin1)
            body.append(data!)
        }
    }
    //
    let filename = "user-profile.jpg"
    let mimetype = "image/jpg"
    body.append(data!)
    data = "Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n".data(using: String.Encoding.isoLatin1)
    body.append(data!)
    data = "Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.isoLatin1)
    //
    body.append(data)
    body.append(imageDataKey as Data)
    data = "\r\n".data(using: String.Encoding.isoLatin1)
    body.append(data!)
    body.append(data)
    print(body.mutableBytes)
    return body
}

class JSON {
    
    func onvertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            print(error.localizedDescription)
        }
    }
    return nil
}
    
}
