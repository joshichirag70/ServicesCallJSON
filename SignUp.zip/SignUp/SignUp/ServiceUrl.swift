//
//  ServiceUrl.swift
//  SignUp
//
//  Created by Mac33 on 30/12/16.
//  Copyright © 2016 JadavMehul. All rights reserved.//

import Foundation

class ServiceUrl:NSObject{
    
    //static let Base = "http://192.168.1.105:7860/"
    static let Base = "http://49.50.81.121:82/" //Nikhil Live
    
    static let Login =  Base + "/security/login"
    static let Signup = Base + "/security/signup"
    static let ProfileImageUpload = Base + "/security/uploadfile"
    
}
